import java.util.ArrayList;
import java.util.Arrays;

import file.MovieDB;
import movies.Actor;
import movies.Movie;
//import sun.awt.geom.AreaOp.AddOp;

/**
 * Movie trivia class providing different methods for querying and updating a movie database.
 */
public class MovieTrivia {
	
	/**
	 * Create instance of movie database
	 */
	MovieDB movieDB = new MovieDB();
	
	
	
	public static void main(String[] args) {
		
		//create instance of movie trivia class
		MovieTrivia mt = new MovieTrivia();
		
		//setup movie trivia class
		mt.setUp("moviedata.txt", "movieratings.csv");
	}
	
	/**
	 * Sets up the Movie Trivia class
	 * @param movieData .txt file
	 * @param movieRatings .csv file
	 */
	public void setUp(String movieData, String movieRatings) {
		//load movie database files
		movieDB.setUp(movieData, movieRatings);
		
		//print all actors and movies
		this.printAllActors();
		this.printAllMovies();		
	}
	
	/**
	 * Prints a list of all actors and the movies they acted in.
	 */
	public void printAllActors () {
		System.out.println(movieDB.getActorsInfo());
	}
	
	/**
	 * Prints a list of all movies and their ratings.
	 */
	public void printAllMovies () {
		System.out.println(movieDB.getMoviesInfo());
	}
	
	
	// TODO add additional methods as specified in the instructions PDF
	/**
	 * Insert given actor and relevant movies into database 
	 * @param actor is a given name of actor
	 * @param movies are the casting movies of this actor 
	 * @param actorInfo is the existing ArrayList created in MovieDB
	 */
	public void insertActor(String actor, String [] movies, ArrayList<Actor>actorsInfo) {
		
		// standardize actor
		String actorForm = actor.trim().toLowerCase(); 
		
		for(int i = 0; i <= actorsInfo.size(); i++) {
		// for(Actor a : actorsInfo){
			// if the actor exists, we should add the string list movies to the actor's casted movie string 
			if(actorForm.equals(actorsInfo.get(i).getName().trim().toLowerCase())) {
				// add movies to movieCast 
				for(int j = 0; j <= movies.length; j++) {
					// standardize the movie string
					String movieForm = movies[j].trim().toLowerCase(); 
					actorsInfo.get(i).getMoviesCast().add(movieForm);
				}
				}else{
				// create a new actor object with given name 
				Actor newActor = new Actor(actorForm); 
				// insert the movies to the actor object
				for(int j = 0; j <= movies.length; j++){
					// standardize the movie string
					String movieForm = movies[j].trim().toLowerCase(); 
					// add the new movie into the created ArrayList moviesCasted
					newActor.getMoviesCast().add(movieForm); 
				}
				// put the new actor object with the standardized movie string into the ArrayList 
				actorsInfo.add(newActor); 
			}
		}
	}

	/**
	 * Inserts given ratings for given movie into database
	 * @param movie
	 * @param ratings
	 * @param moviesInfo
	 */
	public void insertRating(String movie, int [] ratings, ArrayList<Movie>moviesInfo) {
		
		// standardize movie name 
		String movieForm = movie.trim().toLowerCase(); 
		
		// iterate over items in the moviesInfo
		for(int i = 0; i <= moviesInfo.size(); i++) {
			// check if the movie already exists in the database 
			if(movieForm.equals(moviesInfo.get(i).getName().trim().toLowerCase())) {
				// check if the value of ratings normal 
				if(ratings.length != 2) {
					continue;
				}else if (ratings[0] < 0 || ratings[0] > 100 && ratings[1] < 0 || ratings[1] > 100){
					continue; 
				}else {
					moviesInfo.get(i).setCriticRating(ratings[0]); 
					moviesInfo.get(i).setAudienceRating(ratings[1]);
				}
			}else {
				// when the movie doesn't exist in the moviesInfo, we create a new movie object with given movie name 
				Movie newMovie = new Movie(movieForm, ratings[0], ratings[1]); 
				moviesInfo.add(newMovie); 
			}
		}
	    }
	
		/**
		 * Given an actor, returns a list of all movies: return null if actor doesn't exist
		 */
		
		public ArrayList<String> selectWhereActorIs(String actor, ArrayList<Actor>actorsInfo){
			
			// standardize actor name
			String actorForm = actor.trim().toLowerCase(); 
			
			// create a list of all movies for an actor 
			ArrayList<String> AllMovie = new ArrayList<>(); 
	        
			for(int i = 0; i <= AllMovie.size(); i++) {
				
			}
			
			// check if actor exists in the actorsInfo	
			if(actorsInfo.contains(actor)) {
				// iterate over actorsInfo for each existing actor 'a' , convert the actor's name to a standard format
				for (Actor a : actorsInfo) {
				    // if actor == existing actor 
					if(a.getName().toLowerCase().equals(actor)) {
						for(String eachMovie : a.getMoviesCast()){
							AllMovie.add(eachMovie);
						}
						//return AllMovie; 
					}else {
						//return new ArrayList<>();
						}
					}
			}	
			return AllMovie; 
		}
		
		/**
		 * Given a movie, returns the list of all actors in that movie 
		 * 
		 */
		public ArrayList<String> selectWhereMovies(String movie, ArrayList<Actor> actorsInfo){
			//standardize the movie 
			movie = movie.trim().toLowerCase(); 
			
			//create an ArrayList for actors in a movie 
			ArrayList<String> actorsInMovie = new ArrayList<>(); 
			
			//iterate over actorsInfo to find actors in the movie
			for(Actor a : actorsInfo) {
				for (String m : a.getMoviesCast()) {
					if(m.trim().toLowerCase().equals(movie)) {
						actorsInMovie.add(a.getName()); 
						break;
					}
				}
			}
			
			return actorsInMovie;
		
		}
		
		/**
		 * Based on comparison argument and the targeted rating argument, return a list of movies 
		 */
		
		//public ArrayList<String> selectWhereRatingIs(char comparison, int targetRating, boolean isCritic, ArrayList<Movie> moviesInfo){
			ArrayList<String> result = new ArrayList<String>(); 
			
			// check if 
		//}
		
		
		
		// More Fun Methods 
		
		/**
		 * returns a list of all actors that the given actor has ever worked with in any movie except the actor
		 * @param actor
		 * @param actorsInfo
		 * @return
		 */
		//public ArrayList<String> getCoActors(String actor, ArrayList<Actor> actorsInfo){
			
		//}
	}

